## ----double_colon, eval=FALSE--------------------------------------------
## readr::read_csv('fileloc/filename.csv')

