## ----summary_pic, fig.align='center', echo=FALSE, eval=T, cache=FALSE----
knitr::include_graphics('img/198R.png', dpi = NA) # , include=identical(knitr:::pandoc_to(), 'html'

